from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


RECAP_STAGE_DIRS = ("02_recap_production", "01_recap_production")
ASSET_STAGE_DIRS = ("generated_assets", "05_assets_t2i", "04_assets_t2i")
ASSET_GROUPS = ("characters", "props", "scenes")
STYLE_TARGETS = ("realism", "3d-anime", "2d-anime-cartoon")


@dataclass(frozen=True, slots=True)
class RecapAsset:
    asset_type: str
    asset_id: str
    name: str
    description: str
    core_feature: str
    subject_content: str
    style_lighting: str
    prompt: str
    prompt_fields: dict[str, str]
    order: int
    source_payload: dict[str, Any] = field(repr=False)


@dataclass(frozen=True, slots=True)
class RecapBeat:
    beat_id: str
    episode_number: int
    summary: str
    visual_prompt: str
    shot_type: str
    camera_motion: str
    mood: str
    anchor_text: str
    priority: str
    beat_role: str
    pace_weight: str
    asset_focus: str
    source_payload: dict[str, Any] = field(repr=False)

    @property
    def combined_text(self) -> str:
        parts = [
            self.summary,
            self.visual_prompt,
            self.anchor_text,
            self.mood,
            self.asset_focus,
        ]
        return "\n".join(part for part in parts if part)


@dataclass(frozen=True, slots=True)
class GeneratedAsset:
    asset_type: str
    asset_id: str
    asset_name: str
    path: Path

    @property
    def search_tokens(self) -> tuple[str, ...]:
        variants = {
            normalize_match_text(self.asset_id),
            normalize_match_text(self.asset_name),
            normalize_match_text(self.path.stem),
        }
        variants.discard("")
        return tuple(sorted(variants))


@dataclass(slots=True)
class GeneratedAssetIndex:
    root_dir: Path
    items_by_group: dict[str, list[GeneratedAsset]]
    searched_paths: list[Path]

    def has_any_assets(self) -> bool:
        return any(self.items_by_group.get(group) for group in ASSET_GROUPS)

    def available_counts(self) -> dict[str, int]:
        return {group: len(self.items_by_group.get(group, [])) for group in ASSET_GROUPS}

    def select_for_beat(self, group_name: str, beat: RecapBeat) -> tuple[GeneratedAsset | None, str, str]:
        items = list(self.items_by_group.get(group_name, []))
        if not items:
            return None, "missing", f"No generated {group_name} assets were found."

        beat_text = normalize_match_text(beat.combined_text)
        exact_matches: list[GeneratedAsset] = []
        partial_matches: list[GeneratedAsset] = []

        for item in items:
            for token in item.search_tokens:
                if not token:
                    continue
                if token in beat_text:
                    exact_matches.append(item)
                    break
            else:
                if any(shared_token(token, beat_text) for token in item.search_tokens):
                    partial_matches.append(item)

        if exact_matches:
            chosen = sorted(exact_matches, key=lambda item: item.path.name.casefold())[0]
            return chosen, "exact_name_match", f"Matched {group_name[:-1]} asset by exact name in beat text."

        if partial_matches:
            chosen = sorted(partial_matches, key=lambda item: item.path.name.casefold())[0]
            return chosen, "token_overlap_fallback", f"Matched {group_name[:-1]} asset by token overlap fallback."

        if len(items) == 1:
            return items[0], "single_asset_fallback", f"Only one {group_name[:-1]} asset was available; using it as fallback."

        chosen = sorted(items, key=lambda item: item.path.name.casefold())[0]
        return chosen, "first_available_fallback", f"No reliable {group_name[:-1]} asset match was found; using the first available generated asset as fallback."


@dataclass(frozen=True, slots=True)
class RecapBundle:
    recap_dir: Path
    run_root: Path | None
    assets_file: Path
    image_config_file: Path | None
    scene_script_file: Path
    series_title: str
    story_slug: str
    style_target: str
    assets_by_group: dict[str, list[RecapAsset]]
    beats: list[RecapBeat]

    def discover_generated_assets(self, preferred_dirs: list[Path] | None = None) -> GeneratedAssetIndex:
        searched_paths: list[Path] = []
        for candidate in generated_asset_candidates(self.recap_dir, self.run_root, preferred_dirs=preferred_dirs):
            searched_paths.append(candidate)
            if not candidate.exists() or not candidate.is_dir():
                continue

            items_by_group: dict[str, list[GeneratedAsset]] = {group: [] for group in ASSET_GROUPS}
            for group_name in ASSET_GROUPS:
                group_dir = candidate / group_name
                if not group_dir.exists() or not group_dir.is_dir():
                    continue
                for image_path in sorted(group_dir.iterdir(), key=lambda path: path.name.casefold()):
                    if image_path.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}:
                        continue
                    asset_type = group_name[:-1]
                    asset_id = image_path.stem
                    asset_name = name_from_asset_id(asset_id, asset_type)
                    items_by_group[group_name].append(
                        GeneratedAsset(
                            asset_type=asset_type,
                            asset_id=asset_id,
                            asset_name=asset_name,
                            path=image_path.resolve(),
                        )
                    )

            if any(items_by_group[group] for group in ASSET_GROUPS):
                return GeneratedAssetIndex(
                    root_dir=candidate.resolve(),
                    items_by_group=items_by_group,
                    searched_paths=searched_paths,
                )

        return GeneratedAssetIndex(
            root_dir=(searched_paths[0] if searched_paths else self.recap_dir).resolve(),
            items_by_group={group: [] for group in ASSET_GROUPS},
            searched_paths=searched_paths,
        )


def load_recap_bundle(input_path: str | Path) -> RecapBundle:
    recap_dir, run_root = resolve_recap_dir(input_path)
    assets_file = require_existing_file(recap_dir / "02_assets.json", "02_assets.json")
    scene_script_file = require_existing_file(recap_dir / "04_episode_scene_script.json", "04_episode_scene_script.json")
    image_config_file = recap_dir / "03_image_config.json"
    if not image_config_file.exists():
        image_config_file = None

    assets_payload = load_json_file(assets_file)
    scene_script_payload = load_json_file(scene_script_file)
    image_config_payload = load_json_file(image_config_file) if image_config_file else {}

    style_target = normalize_style_target(
        first_text(
            image_config_payload.get("global_style", {}).get("style_preset") if isinstance(image_config_payload.get("global_style"), dict) else "",
            assets_payload.get("style_preset"),
            image_config_payload.get("style_preset"),
        )
    )
    series_title = first_text(
        scene_script_payload.get("series_title"),
        assets_payload.get("series_title"),
        recap_dir.parent.name if recap_dir.parent.name not in RECAP_STAGE_DIRS else recap_dir.name,
    )
    story_slug = first_text(scene_script_payload.get("story_slug"), assets_payload.get("story_slug"), safe_slug(series_title))

    return RecapBundle(
        recap_dir=recap_dir,
        run_root=run_root,
        assets_file=assets_file,
        image_config_file=image_config_file,
        scene_script_file=scene_script_file,
        series_title=series_title,
        story_slug=story_slug,
        style_target=style_target,
        assets_by_group={
            "characters": load_assets_group(assets_payload, "characters"),
            "props": load_assets_group(assets_payload, "props"),
            "scenes": load_assets_group(assets_payload, "scenes"),
        },
        beats=load_beats(scene_script_payload),
    )


def resolve_recap_dir(input_path: str | Path) -> tuple[Path, Path | None]:
    candidate = Path(input_path).expanduser().resolve()
    if not candidate.exists():
        raise FileNotFoundError(f"Recap production path does not exist: {candidate}")

    if candidate.is_file():
        candidate = candidate.parent

    if candidate.name in RECAP_STAGE_DIRS:
        return candidate, candidate.parent

    for stage_name in RECAP_STAGE_DIRS:
        stage_candidate = candidate / stage_name
        if stage_candidate.exists() and stage_candidate.is_dir():
            return stage_candidate.resolve(), candidate.resolve()

    raise ValueError(
        "Expected the recap production output folder itself, or the story run folder that contains "
        "`02_recap_production/` or `01_recap_production/`."
    )


def generated_asset_candidates(
    recap_dir: Path,
    run_root: Path | None,
    *,
    preferred_dirs: list[Path] | None = None,
) -> list[Path]:
    candidates: list[Path] = []
    for candidate in preferred_dirs or []:
        resolved = Path(candidate).expanduser().resolve()
        if resolved not in candidates:
            candidates.append(resolved)
    for base in [recap_dir, run_root] if run_root else [recap_dir]:
        if base is None:
            continue
        for stage_name in ASSET_STAGE_DIRS:
            candidate = (base / stage_name).resolve()
            if candidate not in candidates:
                candidates.append(candidate)
    return candidates


def load_assets_group(payload: dict[str, Any], group_name: str) -> list[RecapAsset]:
    raw_items = payload.get(group_name) or []
    if not isinstance(raw_items, list):
        raise ValueError(f"`{group_name}` in 02_assets.json must be a JSON array.")
    assets: list[RecapAsset] = []
    for index, raw_item in enumerate(raw_items, start=1):
        if not isinstance(raw_item, dict):
            raise ValueError(f"{group_name}[{index}] must be a JSON object.")
        asset_type = str(raw_item.get("asset_type") or group_name[:-1]).strip() or group_name[:-1]
        prompt_fields = raw_item.get("prompt_fields") if isinstance(raw_item.get("prompt_fields"), dict) else {}
        assets.append(
            RecapAsset(
                asset_type=asset_type,
                asset_id=first_text(raw_item.get("asset_id"), f"{asset_type}_{index:03d}"),
                name=first_text(raw_item.get("name"), f"{asset_type}_{index:03d}"),
                description=first_text(raw_item.get("description")),
                core_feature=first_text(raw_item.get("core_feature"), prompt_fields.get("核心特征")),
                subject_content=first_text(raw_item.get("subject_content"), prompt_fields.get("主体内容")),
                style_lighting=first_text(raw_item.get("style_lighting"), prompt_fields.get("风格及光线")),
                prompt=first_text(raw_item.get("visual_prompt"), raw_item.get("prompt"), raw_item.get("prompt_text")),
                prompt_fields={str(key): str(value) for key, value in prompt_fields.items() if str(value).strip()},
                order=coerce_int(raw_item.get("order"), default=index),
                source_payload=raw_item,
            )
        )
    return sorted(assets, key=lambda item: (item.order, item.name.casefold()))


def load_beats(payload: dict[str, Any]) -> list[RecapBeat]:
    episodes = payload.get("episodes") or []
    if not isinstance(episodes, list):
        raise ValueError("`episodes` in 04_episode_scene_script.json must be a JSON array.")
    beats: list[RecapBeat] = []
    for episode in episodes:
        if not isinstance(episode, dict):
            continue
        episode_number = coerce_int(episode.get("episode_number"), default=0)
        scene_beats = episode.get("scene_beats") or []
        if not isinstance(scene_beats, list):
            continue
        for index, raw_beat in enumerate(scene_beats, start=1):
            if not isinstance(raw_beat, dict):
                continue
            beat_id = first_text(raw_beat.get("scene_id"), raw_beat.get("beat_id"), f"ep{episode_number:02d}_s{index:02d}")
            beats.append(
                RecapBeat(
                    beat_id=beat_id,
                    episode_number=episode_number,
                    summary=first_text(raw_beat.get("summary")),
                    visual_prompt=first_text(raw_beat.get("visual_prompt"), raw_beat.get("prompt")),
                    shot_type=first_text(raw_beat.get("shot_type")),
                    camera_motion=first_text(raw_beat.get("camera_motion")),
                    mood=first_text(raw_beat.get("mood")),
                    anchor_text=first_text(raw_beat.get("anchor_text")),
                    priority=first_text(raw_beat.get("priority")),
                    beat_role=first_text(raw_beat.get("beat_role")),
                    pace_weight=first_text(raw_beat.get("pace_weight")),
                    asset_focus=first_text(raw_beat.get("asset_focus")),
                    source_payload=raw_beat,
                )
            )
    return beats


def load_json_file(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON file: {path}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"Expected a top-level JSON object in {path}")
    return payload


def require_existing_file(path: Path, label: str) -> Path:
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"Required recap production file was not found: {label} at {path}")
    return path.resolve()


def normalize_style_target(value: str) -> str:
    text = str(value or "").strip().casefold().replace("_", "-")
    if not text:
        return "2d-anime-cartoon"
    aliases = {
        "2d": "2d-anime-cartoon",
        "2d-anime": "2d-anime-cartoon",
        "2d-anime-cartoon": "2d-anime-cartoon",
        "anime": "2d-anime-cartoon",
        "cartoon": "2d-anime-cartoon",
        "动漫": "2d-anime-cartoon",
        "3d": "3d-anime",
        "3d-anime": "3d-anime",
        "cg": "3d-anime",
        "realism": "realism",
        "realistic": "realism",
        "写实": "realism",
    }
    return aliases.get(text, "2d-anime-cartoon")


def normalize_match_text(value: str) -> str:
    return re.sub(r"[\s_\-]+", "", str(value or "").casefold())


def name_from_asset_id(asset_id: str, asset_type: str) -> str:
    prefix = f"{asset_type}_"
    if asset_id.startswith(prefix):
        return asset_id[len(prefix):]
    return asset_id


def shared_token(value: str, beat_text: str) -> bool:
    tokens = [token for token in re.split(r"[^0-9a-zA-Z\u4e00-\u9fff]+", value) if token]
    return any(token in beat_text for token in tokens)


def safe_slug(value: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff._-]+", "_", str(value).strip())
    cleaned = cleaned.strip("._-")
    return cleaned[:96] or "story"


def first_text(*values: Any) -> str:
    for value in values:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def coerce_int(value: Any, *, default: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed
