---
name: flux-asset-and-scene-generation
display_name: FLUX Asset and Scene Generation
description: Generate FLUX.2 klein assets or keyscenes directly from a recap production output folder. Use when Codex should replace the old recap-to-comfy bridge role by reading `02_recap_production/` or `01_recap_production/`, asking for `asset generation` or `keyscene generation`, building FLUX prompts from recap JSON plus the official FLUX.2 klein prompting guide, and running local image generation with default model routing `black-forest-labs/FLUX.2-klein-9B` for assets and `black-forest-labs/FLUX.2-klein-4B` for keyscenes.
supports_resume: true
input_extensions:
  - .json
folder_mode: non_recursive
metadata:
  i18n:
    display_name:
      en: "FLUX Asset and Scene Generation"
      zh: "FLUX 资产与关键场景生成"
    description:
      en: "Read recap production outputs directly, choose asset or keyscene generation, and run local FLUX.2 klein image generation."
      zh: "直接读取 recap production 产物，选择资产或关键场景生成，并运行本地 FLUX.2 klein 生图。"
    workflow_hint:
      en: "The utility runner prompts in this order: mode first, then recap folder for assets or assets-plus-keyscenes, or recap folder plus assets folder for keyscenes."
      zh: "工具脚本会按此顺序提问：先选模式；若是资产或资产后关键场景则再问 recap 文件夹；若是关键场景则询问 recap 文件夹和资产文件夹。"
    input_hint:
      en: "Send `02_recap_production/`, legacy `01_recap_production/`, the story run folder that contains one of them, or the file `04_episode_scene_script.json`."
      zh: "请提供 `02_recap_production/`、兼容旧链路的 `01_recap_production/`、包含其一的故事运行目录，或 `04_episode_scene_script.json` 文件。"
    output_hint:
      en: "Writes `generated_assets/` or `generated_keyscenes/` plus `manifest.json` inside the skill run output directory."
      zh: "会在技能运行输出目录下写入 `generated_assets/` 或 `generated_keyscenes/` 以及 `manifest.json`。"
    starter_prompt:
      en: "Choose the skill, then reply `1`, `2`, or `3` when prompted for assets, keyscenes, or assets then keyscenes."
      zh: "选择技能后，在模式提示中回复 `1`、`2` 或 `3`，分别表示资产、关键场景或先资产后关键场景。"

steps:
  - number: 1
    title: Generate FLUX Assets or Keyscenes
    description: Read the recap production bundle, prompt for mode when needed, and run local FLUX.2 klein generation.
    write_to: manifest
    default: true

execution:
  strategy: utility_script
  utility_script:
    path: scripts/run_flux_generation.py
    entrypoint: run

output:
  mode: text
  filename_template: manifest.json
  include_prompt_dump: false
---

# FLUX Asset And Scene Generation

Use this skill to run recap-driven FLUX generation locally without making Comfy Bridge the primary path. The skill reads recap production outputs directly, builds prompts in prose using the FLUX.2 klein prompting guide, and writes generated images plus manifests into a clean local folder structure.

## Workflow

1. Ask for mode first: reply `[1] assets`, `[2] keyscenes`, or `[3] assets > keyscenes`.
2. If the user chose `1` or `3`, ask for the recap production output folder path.
3. If the user chose `2`, ask for the recap production output folder path, then ask for the generated assets folder path.
4. Load recap data directly from `02_assets.json` and `04_episode_scene_script.json`, with `03_image_config.json` used when present.
5. If the user chose asset generation, ask whether to generate all assets or a subset. Default to all: `characters`, `props`, `scenes`.
6. Build FLUX prompts from structured recap fields, not from Comfy Bridge payloads.
7. Run local FLUX generation with clear progress output.
8. Save outputs and a manifest under `generated_assets/` or `generated_keyscenes/`.

## Expected Input

Preferred input is the recap production folder itself:

- `outputs/stories/<story_slug>/<run_id>/02_recap_production/`
- legacy fallback: `outputs/stories/<story_slug>/<run_id>/01_recap_production/`

The skill also accepts the story run folder if it contains one of the recap stage folders above.

Required files:

- `02_assets.json`
- `04_episode_scene_script.json`

Optional but used when present:

- `03_image_config.json`

Do not use Comfy Bridge as the primary data source for this skill.

## Asset Mode

Use asset mode to generate clean recap-driven reference images for:

- `characters`
- `props`
- `scenes`

Default behavior:

- ask whether to generate all assets or a subset
- default to all three asset groups
- default model: `black-forest-labs/FLUX.2-klein-9B`

Prompting behavior:

- build richer prose prompts from recap structured fields
- keep source understanding and structured recap fields separate from final prompt rendering
- render the final model-facing prompt in exactly one language based on `config.ini` `[generation] final_prompt_language`
- supported values: `en` and `zh`
- default to `en` when the setting is missing
- warn and fall back to `en` when the setting is invalid
- put the main subject first
- keep setting, detail, lighting, and atmosphere explicit
- keep style explicit at the end
- avoid keyword soup and multi-angle sheet wording

Output layout:

- `generated_assets/characters/*.png`
- `generated_assets/props/*.png`
- `generated_assets/scenes/*.png`
- `generated_assets/manifest.json`

## Keyscene Mode

Use keyscene mode to generate beat-level integrated scenes from recap beats plus generated assets that already exist locally.

Asset lookup order:

- `generated_assets/` beside the recap folder
- sibling story-stage asset folders such as `05_assets_t2i/` or `04_assets_t2i/`

Default behavior:

- default model: `black-forest-labs/FLUX.2-klein-4B`
- use shot-aware reference policy instead of always forcing 3 references
- default to `scene + character` for most beats
- prefer `scene + prop` for insert / object beats
- only keep `scene + character + prop` when the prop is story-critical and matched confidently
- route vehicle-dominant beats into a dedicated vehicle-shot prompt template instead of the generic keyscene template
- default vehicle road and standing beats to `scene + character` so the bike stays physically integrated in the frame
- prefer `scene + prop` for vehicle object / track beats when the rider reference is weak or missing
- use only the assets that are available
- if no generated assets exist, fail clearly and name the searched paths
- if only some assets exist or matching is weak, continue with fallback selection and record the limitation in the manifest
- run semantic scene validation before generation and warn or fail if the selected scene conflicts with beat intent
- if a previous keyscene run crashed after writing some PNGs, reuse those completed outputs and continue from the first missing beat when possible

Prompting behavior:

- use a compressed still-image template: core beat, target relation, one framing clause, one short style clause
- keep source beat understanding separate from the final rendered prompt language
- render the final model-facing keyscene prompt in exactly one language from `config.ini` `[generation] final_prompt_language`
- vehicle shots use a dedicated still-image template: core action, physical scale relation, blocking / scene relation, one framing clause, one short style clause
- do not emit `图1/图2/图3` role instructions in the final prompt
- remove motion language such as `pan`, `push in`, `dolly out`, and `handheld drift`
- use still-image composition terms such as `wide shot`, `medium shot`, `medium close-up`, `insert`, and `over-the-shoulder`
- vehicle shots add compact anti-oversize language so motorcycles and other vehicles stay proportionate to riders, lane / track width, and visible surrounding space
- vehicle road / track shots emphasize blocking such as midground placement, road or track recession, and visible edges or barriers when relevant
- rely on the references to carry appearance, design, and scene detail; the prompt focuses on the target relation and target state
- keep style handling compact: `2D动漫质感`, `3D动漫质感`, or `电影感写实`

Output layout:

- `generated_keyscenes/keyscenes/*.png`
- `generated_keyscenes/manifest.json`

## Style Handling

The runner supports these style targets cleanly through `--style-target`:

- `realism`
- `3d-anime`
- `2d-anime-cartoon`

If the user does not specify a style target, derive it from recap style data:

- `2D` or anime-like recap style -> `2d-anime-cartoon`
- `3D` or CG-like recap style -> `3d-anime`
- realistic / 写实 recap style -> `realism`

## Local Execution

Run the main script through the existing FLUX stack. The skill now shells out to `FLUX/klein.py` with `FLUX/.venv/Scripts/python.exe`, so the app does not need `diffusers` installed in its own interpreter.

```powershell
FLUX\.venv\Scripts\python.exe skills\flux-asset-and-scene-generation\scripts\run_flux_generation.py
```

Non-interactive asset example:

```powershell
FLUX\.venv\Scripts\python.exe skills\flux-asset-and-scene-generation\scripts\run_flux_generation.py `
  --mode asset `
  --recap-folder outputs\stories\zxmoto\20260414_140548\02_recap_production `
  --asset-types characters,props,scenes `
  --non-interactive
```

Non-interactive keyscene example:

```powershell
FLUX\.venv\Scripts\python.exe skills\flux-asset-and-scene-generation\scripts\run_flux_generation.py `
  --mode keyscene `
  --recap-folder outputs\stories\zxmoto\20260414_140548\02_recap_production `
  --non-interactive
```

Useful flags:

- `--asset-types characters,props,scenes`
- `--style-target realism|3d-anime|2d-anime-cartoon`
- `--model <hf-model-id>`
- `--steps <int>`
- `--guidance <float>`
- `--width <int> --height <int>`
- `--seed <int>`
- `--limit <int>`
- `--output-root <dir>`
- `--resume-from <previous_generated_keyscenes_or_session_dir>`
- `--no-resume-keyscenes`
- `--backend klein_cli|mock`
- `--scene-validation off|warn|fail`
- `--debug-keyscene-output`

Language config:

- set `[generation] final_prompt_language = en` for English final prompts
- set `[generation] final_prompt_language = zh` for Chinese final prompts
- if the setting is missing or invalid, the skill uses English final prompts and continues

`--debug-keyscene-output` writes per-beat JSON that now includes:

- chosen references
- shot mode and prompt template
- vehicle preset when applicable
- anti-oversize rules applied
- dropped-prop decisions
- final prompt language
- source structured input plus final rendered prompt
- compressed prompt vs legacy prompt
- scene-validation warnings and candidate scores

## Script Map

- `scripts/run_flux_generation.py`: interactive entry point, beat-aware reference selection, vehicle-shot reference policy, semantic scene validation, batch keyscene generation, debug artifact writing
- `scripts/load_recap_production.py`: recap folder resolution, JSON loading, generated-asset discovery, beat-to-asset matching
- `scripts/build_flux_prompts.py`: FLUX.2 klein prompt construction for assets, compressed shot-aware still-image keyscenes, and vehicle-specific anti-oversize prompt templates
- `scripts/flux_generate.py`: live `FLUX/klein.py` subprocess backend, batch keyscene submission, plus mock backend for validation
- `scripts/validate_flux_skill.py`: local prompt-quality, vehicle-shot, and reference-policy validation plus smoke tests

## Prompting Reference

Read `references/flux2-klein-prompting-application.md` when adjusting prompts. It documents:

- the asset prompt pattern
- the keyscene prompt pattern
- style handling rules
- what this skill deliberately avoids

## Caveats

- Live execution depends on local FLUX model availability and VRAM. The skill defaults to low step counts to stay practical for iterative recap work.
- Keyscene generation assumes generated assets already exist somewhere local. This skill does not call Comfy Bridge to create them.
- Keyscene resume works by reusing completed output PNGs. It is not the engine-level step resume system, so `run.py` still needs to start a fresh skill run; the skill then reuses prior beat outputs when it can find them.
- The mock backend is for validation only. Use the default `klein_cli` backend for real FLUX image generation through `FLUX/klein.py`.
