# Recap To Keyscene Kontext Tasks

- [x] Add a stage-06 ComfyUI-backed keyscene I2I skill
  Evidence: added `SKILL.md`, `README.md`, `scripts/run_keyscene_kontext.py`, and `assets/i2iscenes.json` under `skills/recap_to_keyscene_kontext/`.
- [x] Store a ComfyUI API workflow template inside the skill
  Evidence: `assets/i2iscenes.json` now stores the provided v1 exported ComfyUI API workflow with `UNETLoader`, `DualCLIPLoader`, `VAELoader`, `LoadImage`, `ImageStitch`, `FluxKontextImageScale`, `VAEEncode`, `ReferenceLatent`, `FluxGuidance`, `KSampler`, and `SaveImage` class nodes.
- [x] Implement storyboard-to-asset matching and workflow JSON substitution
  Evidence: `run_keyscene_kontext.py` loads stage-04 `videoarc_storyboard.json`, reads stage-05 grouped asset images, selects primary scene/character/prop references, injects image filenames, prompt text, filename prefix, width, height, and seed, and writes per-beat payload JSON.
- [x] Implement ComfyUI API orchestration
  Evidence: the runner checks `/system_stats`, uploads images through `/upload/image`, submits `/prompt`, polls `/history/{prompt_id}`, downloads `/view`, and records ComfyUI prompt metadata in the stage manifest.
- [x] Support dry validation without a live ComfyUI instance
  Evidence: `--dry-run`, `ONE4ALL_KONTEXT_DRY_RUN=1`, and `ONE4ALL_KONTEXT_LIMIT` produce payloads plus `manifest.json` without API submission.
- [x] Run dry and live one-beat validation against the zxmoto story run
  Evidence: using the provided workflow template, dry validation wrote `outputs/stories/zxmoto/20260413_131152/05_keyscene_i2i_dryrun_validation_provided/manifest.json` with `processed_count: 1` and `failure_count: 0`; live validation wrote `outputs/stories/zxmoto/20260413_131152/05_keyscene_i2i_live_validation_provided/ep01_s01.png` with manifest `success_count: 1` and `failure_count: 0`.

## Reference Order Upgrade

- [x] Trace and document the current reference-stitch node flow
  Evidence: `scripts/run_keyscene_kontext.py` now documents the bundled chain `190/191/194 -> 146 -> 42 -> 192 -> 195 -> 124 -> 177`, and `SKILL.md` / `README.md` now describe the previous fixed `character + prop`, then `+ scene` behavior.
- [x] Separate reference candidate selection, ordering policy, and workflow injection
  Evidence: `run_keyscene_kontext.py` now uses `ReferenceCandidate`, `ReferenceOrderPlan`, `_build_reference_order_plan(...)`, and `_inject_reference_order_into_workflow(...)` instead of assuming one hardcoded stitch order.
- [x] Add configurable order modes with shot-aware default routing
  Evidence: the runner now supports `identity_first`, `staging_first`, and `object_first`, plus default `auto` selection from `_shot_aware_reference_policy(...)`; real storyboard checks mapped `ep01_s04 -> staging_first`, `ep01_s06 -> identity_first`, and `ep01_s08 -> object_first`.
- [x] Make stitch injection respect the selected order and fallback reference count
  Evidence: dry validation with `--reference-order-mode` rewired payloads so `identity_first` produced stitch1 `character + scene` then stitch2 `+ prop`, `staging_first` produced `scene + character` then `+ prop`, and `object_first` produced `prop + scene` then `+ character`; the local validation script also showed 1-reference direct injection and 2-reference first-stitch-only routing.
- [x] Add lightweight debug / validation tooling for reference ordering
  Evidence: `--debug-reference-order` and `ONE4ALL_KONTEXT_DEBUG_REFERENCE_ORDER=1` now print per-beat order selection and target nodes; added `scripts/validate_reference_order.py`, which prints reproducible stitch mappings for all three modes plus 1-reference and 2-reference fallback cases.
- [x] Update skill docs and usage notes for the new ordering controls
  Evidence: `SKILL.md` and `README.md` now document the new modes, auto-policy rules, env / CLI / per-beat overrides, debug output, and where to inspect `manifest.json` for `reference_order` and `workflow_substitutions.reference_injection`.

## Gemini Prompt Cleanup

- [x] Add an optional Gemini prompt-cleanup stage before final keyscene prompt injection
  Evidence: added `scripts/prompt_cleanup.py`; `run_keyscene_kontext.py` now collects compact beat input, optionally calls the configured `gemini` alias, validates structured JSON, assembles the final prompt, and falls back to the legacy prompt automatically.
- [x] Keep prompt cleanup modular and separate from reference ordering / workflow injection
  Evidence: `scripts/prompt_cleanup.py` now separates request construction, response validation, and prompt assembly; `run_keyscene_kontext.py` only orchestrates `_prepare_keyscene_prompt(...)` and then passes the resulting prompt into the unchanged image pipeline.
- [x] Add cleanup debug artifacts and manifest visibility
  Evidence: `--debug-prompt-cleanup` / `ONE4ALL_KONTEXT_DEBUG_PROMPT_CLEANUP=1` now write `prompt_cleanup_debug/<beat>.json` with structured input, raw response, validated payload, final prompt, and legacy prompt; the per-beat manifest now records additive `prompt_cleanup` metadata and artifact path.
- [x] Validate success, fallback, disabled mode, and prompt shortening
  Evidence: `python scripts\\validate_prompt_cleanup.py` passed mocked-success and malformed-response fallback checks, showed `assembled_prompt_length = 162` vs `legacy_prompt_length = 618`, and confirmed fallback restored the legacy prompt; dry-run `--prompt-cleanup-mode off` wrote `outputs/.internal/keyscene_prompt_cleanup/off_mode/manifest.json` with `prompt_cleanup.cleanup_status = "disabled"`; dry-run `--prompt-cleanup-mode gemini` wrote `outputs/.internal/keyscene_prompt_cleanup/gemini_mode_v2/manifest.json` with `prompt_cleanup.cleanup_status = "success"` and `reference_order.shot_priority = "prompt_cleanup:staging"`.
- [x] Fix utility-loader compatibility for sibling prompt-cleanup imports
  Evidence: `run_keyscene_kontext.py` now adds both the repo root and the script directory to `sys.path` before importing `prompt_cleanup`; a `importlib.util.spec_from_file_location(...)` smoke test matching `engine/executor.py` loaded the runner successfully and a dry-run `main([...])` call completed without `No module named 'prompt_cleanup'`.
