from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


RECAP_STAGE_DIRS = ("02_recap_production", "01_recap_production")
CANONICAL_SCENE_SCRIPT = "04_episode_scene_script.json"
OPTIONAL_SCENE_SCRIPT_MD = "04_episode_scene_script.md"


@dataclass(frozen=True, slots=True)
class RecapShot:
    shot_id: str
    episode_number: int
    summary: str
    visual_prompt: str
    shot_type: str
    camera_motion: str
    mood: str
    anchor_text: str
    priority: str
    beat_role: str
    pace_weight: str
    asset_focus: str
    source_payload: dict[str, Any] = field(repr=False)

    @property
    def episode_id(self) -> str:
        return f"ep{self.episode_number:02d}"

    @property
    def combined_text(self) -> str:
        return "\n".join(
            part
            for part in (
                self.summary,
                self.visual_prompt,
                self.anchor_text,
                self.mood,
                self.shot_type,
                self.camera_motion,
            )
            if part
        )


@dataclass(frozen=True, slots=True)
class RecapBundle:
    recap_dir: Path
    run_root: Path | None
    scene_script_file: Path
    scene_script_markdown: Path | None
    assets_file: Path | None
    image_config_file: Path | None
    series_title: str
    story_slug: str
    shots: list[RecapShot]
    selection_notes: tuple[str, ...]


def load_recap_bundle(input_path: str | Path) -> RecapBundle:
    recap_dir, run_root = resolve_recap_dir(input_path)
    scene_script_file, notes = select_scene_script_file(recap_dir)
    payload = load_json_file(scene_script_file)
    series_title = first_text(payload.get("series_title"), recap_dir.parent.name, recap_dir.name)
    story_slug = safe_slug(first_text(payload.get("story_slug"), series_title))
    scene_script_markdown = optional_file(recap_dir / OPTIONAL_SCENE_SCRIPT_MD)
    assets_file = optional_file(recap_dir / "02_assets.json")
    image_config_file = optional_file(recap_dir / "03_image_config.json")
    return RecapBundle(
        recap_dir=recap_dir,
        run_root=run_root,
        scene_script_file=scene_script_file,
        scene_script_markdown=scene_script_markdown,
        assets_file=assets_file,
        image_config_file=image_config_file,
        series_title=series_title,
        story_slug=story_slug,
        shots=load_shots(payload),
        selection_notes=tuple(notes),
    )


def resolve_recap_dir(input_path: str | Path) -> tuple[Path, Path | None]:
    candidate = Path(input_path).expanduser().resolve()
    if not candidate.exists():
        raise FileNotFoundError(f"Recap production path does not exist: {candidate}")
    if candidate.is_file():
        if candidate.name == CANONICAL_SCENE_SCRIPT:
            return candidate.parent.resolve(), candidate.parent.parent.resolve()
        candidate = candidate.parent
    if candidate.name in RECAP_STAGE_DIRS:
        return candidate.resolve(), candidate.parent.resolve()
    for stage_name in RECAP_STAGE_DIRS:
        stage_candidate = candidate / stage_name
        if stage_candidate.exists() and stage_candidate.is_dir():
            return stage_candidate.resolve(), candidate.resolve()
    raise ValueError(
        "Expected the recap production folder itself, the story run folder that contains it, "
        f"or the file `{CANONICAL_SCENE_SCRIPT}`."
    )


def select_scene_script_file(recap_dir: Path) -> tuple[Path, list[str]]:
    notes: list[str] = []
    canonical = recap_dir / CANONICAL_SCENE_SCRIPT
    if canonical.exists() and canonical.is_file():
        notes.append(f"Selected canonical scene script: {canonical.name}")
        return canonical.resolve(), notes

    candidates = sorted(recap_dir.glob("*episode*scene*script*.json"), key=lambda path: path.name.casefold())
    if candidates:
        chosen = candidates[0].resolve()
        notes.append(f"Canonical scene script was missing; selected fallback JSON: {chosen.name}")
        if len(candidates) > 1:
            notes.append(f"Multiple scene-script candidates were found; chose the first sorted JSON file: {chosen.name}")
        return chosen, notes

    raise FileNotFoundError(
        f"Could not find `{CANONICAL_SCENE_SCRIPT}` or another matching scene-script JSON file in {recap_dir}"
    )


def load_shots(payload: dict[str, Any]) -> list[RecapShot]:
    episodes = payload.get("episodes")
    if not isinstance(episodes, list):
        raise ValueError("`episodes` in the episode scene script must be a JSON array.")
    shots: list[RecapShot] = []
    for episode in episodes:
        if not isinstance(episode, dict):
            continue
        episode_number = coerce_int(episode.get("episode_number"), default=0)
        scene_beats = episode.get("scene_beats")
        if not isinstance(scene_beats, list):
            continue
        for index, beat in enumerate(scene_beats, start=1):
            if not isinstance(beat, dict):
                continue
            shot_id = first_text(beat.get("scene_id"), beat.get("shot_id"), f"ep{episode_number:02d}_s{index:02d}")
            shots.append(
                RecapShot(
                    shot_id=shot_id,
                    episode_number=episode_number,
                    summary=first_text(beat.get("summary")),
                    visual_prompt=first_text(beat.get("visual_prompt"), beat.get("prompt")),
                    shot_type=first_text(beat.get("shot_type")),
                    camera_motion=first_text(beat.get("camera_motion")),
                    mood=first_text(beat.get("mood")),
                    anchor_text=first_text(beat.get("anchor_text")),
                    priority=first_text(beat.get("priority")),
                    beat_role=first_text(beat.get("beat_role")),
                    pace_weight=first_text(beat.get("pace_weight")),
                    asset_focus=first_text(beat.get("asset_focus")),
                    source_payload=beat,
                )
            )
    if not shots:
        raise ValueError("No scene beats were found in the episode scene script.")
    return shots


def load_json_file(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON file: {path}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"Expected a top-level JSON object in {path}")
    return payload


def optional_file(path: Path) -> Path | None:
    return path.resolve() if path.exists() and path.is_file() else None


def first_text(*values: object) -> str:
    for value in values:
        text = str(value or "").strip()
        if text:
            return text
    return ""


def coerce_int(value: Any, *, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def safe_slug(value: str) -> str:
    cleaned = "".join(char.lower() if char.isalnum() else "-" for char in str(value or ""))
    while "--" in cleaned:
        cleaned = cleaned.replace("--", "-")
    cleaned = cleaned.strip("-")
    return cleaned or "story"
