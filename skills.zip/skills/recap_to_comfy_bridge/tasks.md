# Recap To Comfy Bridge Tasks

- [x] Add a deterministic script-backed bridge skill inside `skills/`.
  Evidence: created `skills/recap_to_comfy_bridge/SKILL.md` plus `skills/recap_to_comfy_bridge/scripts/convert_recap_to_videoarc.py`.
- [x] Register the bridge in the shared ONE4ALL skill catalog.
  Evidence: `skills/registry.yaml` now includes `id: recap_to_comfy_bridge`.
- [x] Convert recap_production outputs into VideoArc-style assets and storyboard payloads.
  Evidence: the bridge script now writes `videoarc_assets.json`, `videoarc_storyboard.json`, and `bridge_summary.json`.
- [x] Keep the bridge local, inspectable, and failure-forward.
  Evidence: the script validates required sibling recap files, writes human-readable JSON, and raises clear errors for missing inputs.
