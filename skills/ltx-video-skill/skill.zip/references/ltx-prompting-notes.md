# LTX Prompting Notes

This skill builds one shot prompt per recap beat for later LTX clip generation.

## Core Rule

Describe what the viewer should literally see moving next.

## Prompt Priorities

1. Visible action first
2. Secondary body or object motion only if relevant
3. Environment motion only if it affects the shot
4. Camera motion only if it helps the shot
5. Keep the result concise and physically plausible

## What To Avoid

- recap narration
- thematic explanation
- poetic summary lines
- long static description already implied by the image
- inventing characters, props, or story beats
- one beat turning into multiple separate shots

## Structured Fields

The prompt director works through structured fields before assembling a final paragraph:

- `primary_action`
- `secondary_motion`
- `environment_motion`
- `camera_motion`
- `emotion`
- `duration_hint`
- `final_prompt`

## Validation Rules

The skill treats these as warning or fallback triggers:

- missing required fields
- empty `final_prompt`
- very long `final_prompt`
- recap-like narration such as explanation, interpretation, or symbolism
- malformed JSON

## Future v2 Direction

v2 can later reuse the saved prompt pack together with:

- keyframes or keyscenes
- clip duration planning
- LTX render configuration
- clip stitching and retry logic
