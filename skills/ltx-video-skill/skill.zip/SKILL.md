---
name: ltx-video-skill
display_name: LTX Video Skill
description: Read a recap production output folder, extract episode shot beats, call the configured `gemini` model alias from `config.ini` as a prompt director, and save structured LTX-ready video prompts for later clip generation. Use when Codex should create shot-level motion prompts from `02_recap_production/` or legacy `01_recap_production/` without rendering video yet.
supports_resume: false
input_extensions:
  - .json
folder_mode: non_recursive
metadata:
  i18n:
    display_name:
      en: "LTX Video Skill"
      zh: "LTX 视频提示词技能"
    description:
      en: "Turn recap production beats into structured LTX-ready shot prompts with the configured Gemini alias."
      zh: "将 recap production 的分镜 beat 转换为结构化 LTX 视频提示词，并使用已配置的 Gemini 别名。"
    workflow_hint:
      en: "This v1 skill reads the recap folder, directs Gemini to rewrite each beat into a structured motion prompt, validates the JSON, and saves prompt outputs for later clip generation."
      zh: "这个 v1 技能会读取 recap 文件夹，调用 Gemini 将每个 beat 改写为结构化动态提示词，校验 JSON，并保存供后续视频生成使用的提示词结果。"
    input_hint:
      en: "Send the `02_recap_production/` folder, the legacy `01_recap_production/` folder, the story run folder that contains one of them, or `04_episode_scene_script.json`."
      zh: "请提供 `02_recap_production/`、兼容旧链路的 `01_recap_production/`、包含其一的故事运行目录，或 `04_episode_scene_script.json` 文件。"
    output_hint:
      en: "Writes `generated_ltx_prompts/prompts.json`, `prompts_by_episode.json`, optional `debug/`, and `manifest.json`."
      zh: "会写出 `generated_ltx_prompts/prompts.json`、`prompts_by_episode.json`、可选 `debug/` 和 `manifest.json`。"
    starter_prompt:
      en: "Use this skill when you have a recap production folder and want structured LTX-ready shot prompts, not rendered clips."
      zh: "当你已经有 recap production 文件夹，并且只需要结构化 LTX 分镜提示词而不是视频渲染时，使用这个技能。"

steps:
  - number: 1
    title: Generate LTX Prompt Pack
    description: Read the recap production bundle, direct Gemini to rewrite each shot beat into LTX-ready prompt JSON, validate the results, and save a prompt pack for later clip generation.
    write_to: manifest
    default: true

execution:
  strategy: utility_script
  utility_script:
    path: scripts/run_ltx_prompt_generation.py
    entrypoint: run

output:
  mode: text
  filename_template: manifest.json
  include_prompt_dump: false
---

# LTX Video Skill

Use this skill when recap production has already produced `04_episode_scene_script.json` and the next need is shot-level video prompting, not clip rendering. v1 stops at prompt generation. It converts recap-style beat text into structured LTX-ready prompt outputs that a later v2 stage can pair with keyframes and send to an actual LTX video backend.

## Workflow

1. Ask for the recap production output folder path.
2. Read the recap production bundle directly, preferring `04_episode_scene_script.json`.
3. Extract episodes and shot beats into compact structured inputs.
4. Call the configured `gemini` alias from `config.ini` as a prompt director.
5. Validate Gemini JSON and sanitize the prompt payload.
6. If Gemini fails or returns malformed output, fall back to a deterministic local prompt.
7. Save structured outputs under `generated_ltx_prompts/`.

## Expected Input

Preferred inputs:

- `outputs/stories/<story_slug>/<run_id>/02_recap_production/`
- legacy fallback: `outputs/stories/<story_slug>/<run_id>/01_recap_production/`
- the story run folder that contains one of those stage folders
- `04_episode_scene_script.json`

Required file:

- `04_episode_scene_script.json`

Optional supporting files:

- `04_episode_scene_script.md`
- `02_assets.json`
- `03_image_config.json`

If multiple relevant files exist, the skill prefers the canonical JSON scene script and records what it selected in the manifest.

## What Gemini Does

Gemini is used as a prompt director, not as a video model. For each beat, it rewrites recap-style prose into a structured motion prompt with fields such as:

- `episode_id`
- `shot_id`
- `shot_type`
- `primary_action`
- `secondary_motion`
- `environment_motion`
- `camera_motion`
- `emotion`
- `duration_hint`
- `final_prompt`

The final prompt is a single coherent paragraph focused on what a viewer should literally see happening next.

## Prompting Rules

The skill directs Gemini to:

- lead with visible action
- keep motion concrete and physically plausible
- include environment motion only when useful
- include camera motion only if it materially helps the shot
- avoid recap narration and abstract theme language
- avoid inventing major story facts, characters, or props
- keep one beat to one shot prompt

If the source image or future keyframe would already establish the subject, scene, and style, Gemini is told to focus on what changes next rather than re-describing everything static.

## Output Layout

- `generated_ltx_prompts/prompts.json`
- `generated_ltx_prompts/prompts_by_episode.json`
- `generated_ltx_prompts/manifest.json`
- `generated_ltx_prompts/debug/*.json` when debug output is enabled

Manifest fields include:

- input folder
- timestamp
- selected episode-scene script path
- model alias used
- resolved model route
- shot count
- success / fallback counts
- validation summary
- output paths

## Local Execution

Interactive:

```powershell
python skills\ltx-video-skill\scripts\run_ltx_prompt_generation.py
```

Non-interactive example:

```powershell
python skills\ltx-video-skill\scripts\run_ltx_prompt_generation.py `
  --recap-folder OUTPUTSSAVED\2222\02_recap_production `
  --model-alias gemini `
  --debug-output `
  --limit 3 `
  --non-interactive
```

Useful flags:

- `--model-alias gemini`
- `--limit <int>`
- `--shot-id <epXX_sYY>`
- `--output-root <dir>`
- `--debug-output`
- `--non-interactive`

## Script Map

- `scripts/run_ltx_prompt_generation.py`: utility runner, progress output, prompt generation loop, output writing
- `scripts/load_recap_production.py`: recap-folder resolution and beat extraction
- `scripts/build_ltx_prompt_requests.py`: compact Gemini request payloads and deterministic fallback prompt construction
- `scripts/gemini_prompt_director.py`: Gemini call, JSON parsing, validation, and fallback routing
- `scripts/validate_ltx_prompts.py`: prompt-output validation plus fallback/self-test tooling

## Prompting Notes

Read `references/ltx-prompting-notes.md` when adjusting prompt shape or validation rules.

## Scope Guard

v1 does not render video clips. It only writes structured prompt packs. A future v2 can later:

- read these prompt outputs
- pair them with keyframes or keyscenes
- call an LTX backend to render clips

## Caveats

- Real Gemini calls depend on the configured OpenRouter/OpenAI environment keys and the `gemini` alias in `config.ini`.
- Prompt quality is only as good as the recap beat quality. Weak or overly abstract beats will trigger more fallback prompts.
- v1 preserves a prompt-pack structure for downstream video work but does not yet manage timing, clip stitching, or render retries.
