from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))
REPO_ROOT = Path(__file__).resolve().parents[3]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from build_ltx_prompt_requests import build_ltx_prompt_request
from gemini_prompt_director import direct_shot_prompt_with_gemini
from load_recap_production import RecapShot, load_recap_bundle
from validate_ltx_prompts import validate_generated_prompt_payload


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read a recap production folder and generate structured LTX-ready shot prompts with Gemini."
    )
    parser.add_argument("--recap-folder", help="Path to the recap production folder, story run folder, or 04_episode_scene_script.json")
    parser.add_argument("--model-alias", default="gemini", help="Configured model alias from config.ini. Default: gemini.")
    parser.add_argument("--limit", type=int, help="Only process the first N shots.")
    parser.add_argument("--shot-id", help="Only process one specific shot id, for example ep01_s03.")
    parser.add_argument("--output-root", help="Optional output directory. Defaults to a generated_ltx_prompts folder beside the recap bundle.")
    parser.add_argument("--debug-output", action="store_true", help="Write per-shot debug JSON with request, raw response, and fallback details.")
    parser.add_argument("--non-interactive", action="store_true", help="Fail instead of prompting for missing recap folder.")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    configure_utf8_console()
    args = parse_args(argv)
    manifest_path = execute_generation(args)
    safe_print(f"[ltx-skill] completed: {manifest_path}")
    return 0


def run(
    *,
    repo_root: Path,
    skill,
    document,
    output_dir: Path,
    step_number: int,
    runtime_values: dict[str, Any],
    state,
) -> dict[str, Any]:
    del step_number, state
    configure_utf8_console()
    default_recap_folder = normalize_recap_folder_input(runtime_values.get("recap_folder") or str(document.path))
    recap_folder = prompt_recap_folder_with_default(non_interactive=False, default_value=default_recap_folder)
    args = argparse.Namespace(
        recap_folder=recap_folder,
        model_alias=runtime_values.get("model_alias") or "gemini",
        limit=optional_int(runtime_values.get("limit")),
        shot_id=runtime_values.get("shot_id"),
        output_root=str((output_dir.resolve() / "generated_ltx_prompts")),
        debug_output=truthy(runtime_values.get("debug_output")),
        non_interactive=True,
    )
    manifest_path = execute_generation(args, repo_root=repo_root, skill=skill)
    return {
        "primary_output": manifest_path,
        "output_files": {
            "primary": manifest_path,
            "manifest": manifest_path,
        },
        "notes": [
            f"Recap source: {document.path}",
            f"Model alias: {args.model_alias}",
            f"Manifest: {manifest_path}",
        ],
        "status": "completed",
    }


def execute_generation(
    args: argparse.Namespace,
    *,
    repo_root: Path | None = None,
    skill: Any = None,
) -> Path:
    repo_root = repo_root or Path(__file__).resolve().parents[3]
    recap_folder = (
        args.recap_folder
        if args.non_interactive and args.recap_folder
        else prompt_recap_folder_with_default(non_interactive=args.non_interactive, default_value=args.recap_folder)
    )
    safe_print(f"[ltx-skill] reading recap production folder: {recap_folder}")
    bundle = load_recap_bundle(recap_folder)
    safe_print(f"[ltx-skill] locating episode script: {bundle.scene_script_file}")
    for note in bundle.selection_notes:
        safe_print(f"[ltx-skill] {note}")

    shots = select_shots(bundle.shots, limit=args.limit, shot_id=args.shot_id)
    safe_print(f"[ltx-skill] extracting shot beats: {len(shots)}")

    output_root = resolve_output_dir(args.output_root, bundle.recap_dir, "generated_ltx_prompts")
    output_root.mkdir(parents=True, exist_ok=True)
    debug_dir = output_root / "debug"
    if args.debug_output:
        debug_dir.mkdir(parents=True, exist_ok=True)

    items: list[dict[str, Any]] = []
    by_episode: dict[str, list[dict[str, Any]]] = {}
    fallback_count = 0
    success_count = 0
    validation_issue_count = 0
    resolved_route = ""
    resolved_model = ""

    total = len(shots)
    for index, shot in enumerate(shots, start=1):
        request = build_ltx_prompt_request(shot, total_shots=total, shot_index=index)
        safe_print(f"[ltx-skill] sending shot {index}/{total} to Gemini: {shot.shot_id}")
        result = direct_shot_prompt_with_gemini(
            repo_root=repo_root,
            skill=skill,
            request_payload=request,
            model_alias=args.model_alias,
        )
        resolved_route = result.route or resolved_route
        resolved_model = result.model or resolved_model
        validation = validate_generated_prompt_payload(result.payload)
        status = "valid" if validation.is_valid else "invalid"
        safe_print(f"[ltx-skill] validating generated prompt: {shot.shot_id} -> {status}")
        if result.status != "success":
            fallback_count += 1
        else:
            success_count += 1
        if not validation.is_valid:
            validation_issue_count += len(validation.issues)

        item = build_prompt_item(
            shot=shot,
            payload=result.payload,
            result=result,
            validation_issues=list(validation.issues),
        )
        items.append(item)
        by_episode.setdefault(shot.episode_id, []).append(item)

        if args.debug_output:
            write_debug_artifact(
                debug_dir / f"{safe_slug(shot.shot_id)}.json",
                shot=shot,
                request=request.structured_input,
                result=result,
                validation_issues=list(validation.issues),
            )

    prompts_path = output_root / "prompts.json"
    prompts_payload = {
        "schema": "ltx_prompt_pack_v1",
        "series_title": bundle.series_title,
        "story_slug": bundle.story_slug,
        "model_alias": args.model_alias,
        "resolved_model_route": resolved_route,
        "resolved_model": resolved_model,
        "item_count": len(items),
        "items": items,
    }
    prompts_path.write_text(json.dumps(prompts_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    prompts_by_episode_path = output_root / "prompts_by_episode.json"
    prompts_by_episode_payload = {
        "schema": "ltx_prompt_pack_by_episode_v1",
        "series_title": bundle.series_title,
        "episodes": [
            {
                "episode_id": episode_id,
                "shot_count": len(episode_items),
                "items": episode_items,
            }
            for episode_id, episode_items in sorted(by_episode.items())
        ],
    }
    prompts_by_episode_path.write_text(
        json.dumps(prompts_by_episode_payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    manifest_path = output_root / "manifest.json"
    manifest = {
        "schema": "ltx_prompt_generation_manifest_v1",
        "timestamp": timestamp_now(),
        "input_folder": str(bundle.recap_dir),
        "selected_scene_script": str(bundle.scene_script_file),
        "selection_notes": list(bundle.selection_notes),
        "series_title": bundle.series_title,
        "story_slug": bundle.story_slug,
        "model_alias_used": args.model_alias,
        "resolved_model_route": resolved_route,
        "resolved_model": resolved_model,
        "shot_count": len(items),
        "success_count": success_count,
        "fallback_count": fallback_count,
        "validation_issue_count": validation_issue_count,
        "validation_status": "valid" if validation_issue_count == 0 else "warnings",
        "output_root": str(output_root),
        "output_paths": {
            "prompts": str(prompts_path),
            "prompts_by_episode": str(prompts_by_episode_path),
            "debug": str(debug_dir) if args.debug_output else None,
            "manifest": str(manifest_path),
        },
    }
    safe_print("[ltx-skill] saving structured prompt outputs")
    safe_print("[ltx-skill] writing manifest")
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest_path


def build_prompt_item(*, shot: RecapShot, payload: dict[str, str], result, validation_issues: list[str]) -> dict[str, Any]:
    return {
        "episode_id": payload.get("episode_id") or shot.episode_id,
        "shot_id": payload.get("shot_id") or shot.shot_id,
        "shot_type": payload.get("shot_type") or shot.shot_type,
        "primary_action": payload.get("primary_action", ""),
        "secondary_motion": payload.get("secondary_motion", ""),
        "environment_motion": payload.get("environment_motion", ""),
        "camera_motion": payload.get("camera_motion", ""),
        "emotion": payload.get("emotion", ""),
        "duration_hint": payload.get("duration_hint", ""),
        "final_prompt": payload.get("final_prompt", ""),
        "source_summary": shot.summary,
        "source_visual_prompt": shot.visual_prompt,
        "source_anchor_text": shot.anchor_text,
        "source_camera_motion": shot.camera_motion,
        "source_shot_type": shot.shot_type,
        "prompt_source": result.source,
        "generation_status": result.status,
        "warning": result.warning,
        "validation_issues": validation_issues,
        "model_alias": result.model_alias,
        "resolved_model": result.model,
        "resolved_route": result.route,
    }


def write_debug_artifact(
    path: Path,
    *,
    shot: RecapShot,
    request: dict[str, Any],
    result,
    validation_issues: list[str],
) -> None:
    payload = {
        "shot_id": shot.shot_id,
        "episode_id": shot.episode_id,
        "request": request,
        "result_status": result.status,
        "result_source": result.source,
        "warning": result.warning,
        "payload": result.payload,
        "validation_issues": validation_issues,
        "raw_response_text": result.raw_response_text,
        "raw_response_json": result.raw_response_json,
        "resolved_model": result.model,
        "resolved_route": result.route,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def select_shots(shots: list[RecapShot], *, limit: int | None, shot_id: str | None) -> list[RecapShot]:
    selected = shots
    if shot_id:
        selected = [shot for shot in shots if shot.shot_id == shot_id]
        if not selected:
            raise ValueError(f"Shot id not found in recap bundle: {shot_id}")
    if limit is not None:
        selected = selected[: max(limit, 0)]
    if not selected:
        raise ValueError("No shots were selected for prompt generation.")
    return selected


def resolve_output_dir(output_root: str | None, recap_dir: Path, folder_name: str) -> Path:
    if output_root:
        return Path(output_root).expanduser().resolve()
    return (recap_dir.parent / folder_name).resolve()


def normalize_recap_folder_input(value: str | None) -> str | None:
    if not value:
        return None
    candidate = Path(value).expanduser()
    if candidate.is_file() and candidate.name == "04_episode_scene_script.json":
        return str(candidate.parent)
    return str(candidate)


def prompt_recap_folder_with_default(*, non_interactive: bool, default_value: str | None) -> str:
    if non_interactive:
        if not default_value:
            raise ValueError("Missing required --recap-folder for non-interactive execution.")
        return default_value
    prompt = "What is the recap production output folder path?"
    if default_value:
        prompt += f" Press Enter to use [{default_value}]: "
    else:
        prompt += " "
    response = input(prompt).strip()
    if not response:
        response = default_value or ""
    if not response:
        raise ValueError("A recap production output folder path is required.")
    return response


def optional_int(value: Any) -> int | None:
    try:
        return int(value) if value not in {None, ""} else None
    except (TypeError, ValueError):
        return None


def truthy(value: Any) -> bool:
    return str(value or "").strip().casefold() in {"1", "true", "yes", "on"}


def timestamp_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def safe_slug(value: str) -> str:
    cleaned = "".join(char.lower() if char.isalnum() else "-" for char in str(value or ""))
    while "--" in cleaned:
        cleaned = cleaned.replace("--", "-")
    cleaned = cleaned.strip("-")
    return cleaned or "item"


def safe_print(message: str) -> None:
    text = str(message)
    try:
        print(text)
    except UnicodeEncodeError:
        print(text.encode("ascii", "backslashreplace").decode("ascii"))


def configure_utf8_console() -> None:
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except OSError:
                continue


if __name__ == "__main__":
    raise SystemExit(main())
