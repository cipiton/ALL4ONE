from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


REQUIRED_FIELDS = (
    "episode_id",
    "shot_id",
    "shot_type",
    "primary_action",
    "final_prompt",
)
STRUCTURED_FIELDS = (
    "secondary_motion",
    "environment_motion",
    "camera_motion",
    "emotion",
    "duration_hint",
)
RECAP_LIKE_TOKENS = (
    "画面强调",
    "象征",
    "预示",
    "意味着",
    "命运",
    "主题",
    "现实与",
    "形成强反差",
)
MAX_FINAL_PROMPT_CHARS = 220


@dataclass(frozen=True, slots=True)
class PromptValidationResult:
    is_valid: bool
    issues: tuple[str, ...]


def validate_generated_prompt_payload(payload: dict[str, Any]) -> PromptValidationResult:
    issues: list[str] = []
    for field_name in REQUIRED_FIELDS:
        value = str(payload.get(field_name) or "").strip()
        if not value:
            issues.append(f"missing required field: {field_name}")
    for field_name in STRUCTURED_FIELDS:
        if field_name not in payload:
            issues.append(f"missing structured field: {field_name}")
    final_prompt = normalize_text(payload.get("final_prompt"))
    if not final_prompt:
        issues.append("final_prompt is empty")
    if "\n" in str(payload.get("final_prompt") or ""):
        issues.append("final_prompt must be a single paragraph")
    if len(final_prompt) > MAX_FINAL_PROMPT_CHARS:
        issues.append(f"final_prompt is too long ({len(final_prompt)} chars > {MAX_FINAL_PROMPT_CHARS})")
    lowered = final_prompt.casefold()
    if any(token.casefold() in lowered for token in RECAP_LIKE_TOKENS):
        issues.append("final_prompt still looks recap-like instead of shot-action-focused")
    return PromptValidationResult(is_valid=not issues, issues=tuple(issues))


def validate_prompts_file(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    items = payload.get("items") if isinstance(payload, dict) else None
    if not isinstance(items, list):
        raise ValueError(f"`items` array not found in {path}")
    per_shot: list[dict[str, Any]] = []
    valid_count = 0
    for item in items:
        if not isinstance(item, dict):
            continue
        result = validate_generated_prompt_payload(item)
        if result.is_valid:
            valid_count += 1
        per_shot.append(
            {
                "shot_id": item.get("shot_id"),
                "is_valid": result.is_valid,
                "issues": list(result.issues),
            }
        )
    return {
        "prompts_file": str(path.resolve()),
        "item_count": len(per_shot),
        "valid_count": valid_count,
        "invalid_count": len(per_shot) - valid_count,
        "items": per_shot,
    }


def run_fallback_self_test(repo_root: Path) -> dict[str, Any]:
    script_dir = Path(__file__).resolve().parent
    if str(script_dir) not in sys.path:
        sys.path.insert(0, str(script_dir))
    from build_ltx_prompt_requests import build_ltx_prompt_request
    from gemini_prompt_director import direct_shot_prompt_with_gemini
    from load_recap_production import RecapShot

    shot = RecapShot(
        shot_id="ep99_s01",
        episode_number=99,
        summary="张雪骑着黄摩托冲进暴雨乡道。",
        visual_prompt="暴雨乡道上，黄摩托冲起泥水，镜头继续跟住主体前进。",
        shot_type="wide shot",
        camera_motion="slow pan right",
        mood="urgent, stormy",
        anchor_text="他继续往前冲。",
        priority="high",
        beat_role="hook",
        pace_weight="short",
        asset_focus="interaction",
        source_payload={},
    )
    request = build_ltx_prompt_request(shot, total_shots=1, shot_index=1)

    class StubResponse:
        text = "{not-json"
        raw_response = {"choices": []}
        model = "google/gemini-2.5-flash"

    result = direct_shot_prompt_with_gemini(
        repo_root=repo_root,
        skill=None,
        request_payload=request,
        model_alias="gemini",
        llm_callable=lambda *args, **kwargs: StubResponse(),
    )
    validation = validate_generated_prompt_payload(result.payload)
    return {
        "status": result.status,
        "warning": result.warning,
        "source": result.source,
        "payload": result.payload,
        "validation": {
            "is_valid": validation.is_valid,
            "issues": list(validation.issues),
        },
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate generated LTX prompt outputs or run the malformed-Gemini fallback self-test.")
    parser.add_argument("path", nargs="?", help="Path to prompts.json or a generated_ltx_prompts output directory.")
    parser.add_argument("--self-test-fallback", action="store_true", help="Run a malformed-Gemini fallback test.")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    configure_utf8_console()
    args = parse_args(argv)
    repo_root = Path(__file__).resolve().parents[3]
    if args.self_test_fallback:
        print(json.dumps(run_fallback_self_test(repo_root), ensure_ascii=False, indent=2))
        return 0
    if not args.path:
        raise ValueError("Provide a prompts.json path or use --self-test-fallback.")
    candidate = Path(args.path).expanduser().resolve()
    prompts_file = candidate / "prompts.json" if candidate.is_dir() else candidate
    print(json.dumps(validate_prompts_file(prompts_file), ensure_ascii=False, indent=2))
    return 0


def normalize_text(value: Any) -> str:
    return " ".join(str(value or "").replace("\r\n", " ").replace("\n", " ").split()).strip()


def configure_utf8_console() -> None:
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8", errors="replace")
            except OSError:
                continue


if __name__ == "__main__":
    raise SystemExit(main())
