from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any

from load_recap_production import RecapShot


SHOT_TYPE_MAP = {
    "wide shot": "wide shot",
    "medium shot": "medium shot",
    "medium close-up": "medium close-up",
    "close-up": "close-up",
    "over-the-shoulder": "over-the-shoulder",
    "insert": "insert shot",
    "montage": "montage shot",
}

CAMERA_MOTION_MAP = {
    "static": "",
    "slow pan right": "镜头缓慢向右平移",
    "slow pan left": "镜头缓慢向左平移",
    "slow push in": "镜头缓慢推进",
    "slow dolly in": "镜头缓慢推近",
    "slow dolly out": "镜头缓慢拉远",
    "handheld drift": "轻微手持漂移",
    "slow tilt down": "镜头缓慢下倾",
    "slow tilt up": "镜头缓慢上仰",
}

DURATION_HINT_MAP = {
    "short": "2-3s",
    "medium": "3-5s",
    "long": "4-6s",
}


@dataclass(frozen=True, slots=True)
class LtxPromptRequest:
    structured_input: dict[str, Any]
    messages: list[Any]
    fallback_payload: dict[str, str]


def build_ltx_prompt_request(shot: RecapShot, *, total_shots: int, shot_index: int) -> LtxPromptRequest:
    structured_input = {
        "episode_id": shot.episode_id,
        "shot_id": shot.shot_id,
        "shot_number": shot_index,
        "total_shots": total_shots,
        "summary": compact_text(shot.summary, limit=180),
        "visual_prompt": compact_text(shot.visual_prompt, limit=260),
        "anchor_text": compact_text(shot.anchor_text, limit=100),
        "shot_type": normalize_shot_type(shot.shot_type),
        "camera_motion": normalize_camera_motion(shot.camera_motion),
        "emotion": compact_text(visible_emotion(shot), limit=48),
        "duration_hint": infer_duration_hint(shot.pace_weight),
        "priority": compact_text(shot.priority, limit=24),
        "beat_role": compact_text(shot.beat_role, limit=24),
        "asset_focus": compact_text(shot.asset_focus, limit=24),
    }
    fallback_payload = build_fallback_payload(shot)
    return LtxPromptRequest(
        structured_input=structured_input,
        messages=build_director_messages(structured_input),
        fallback_payload=fallback_payload,
    )


def build_director_messages(structured_input: dict[str, Any]) -> list[Any]:
    from engine.models import PromptMessage

    schema = {
        "episode_id": "string",
        "shot_id": "string",
        "shot_type": "string",
        "primary_action": "string",
        "secondary_motion": "string",
        "environment_motion": "string",
        "camera_motion": "string",
        "emotion": "string",
        "duration_hint": "string",
        "final_prompt": "string",
    }
    system = (
        "You are the ONE4ALL LTX prompt director. "
        "You convert one recap-style scene beat into one structured LTX-ready shot prompt. "
        "Return JSON only.\n\n"
        "Rules:\n"
        "- Focus on visible action first.\n"
        "- Describe concrete motion, not recap meaning.\n"
        "- Include environment motion only if visually relevant.\n"
        "- Include camera motion only if useful for the shot.\n"
        "- Keep the final prompt concise, single-paragraph, and physically plausible.\n"
        "- Do not invent major story facts, new characters, or new props.\n"
        "- Do not write like a novel recap.\n"
        "- Do not explain themes, symbolism, or backstory.\n"
        "- Preserve chronology and one beat = one shot.\n"
        "- If the image would already establish the subject, scene, and style, focus the final prompt on what changes next.\n"
        "- Use Chinese in the output values so the prompt stays aligned with the source beat language."
    )
    user = (
        "Convert this beat into the target schema.\n"
        f"Schema:\n{json.dumps(schema, ensure_ascii=False, indent=2)}\n\n"
        f"Shot input:\n{json.dumps(structured_input, ensure_ascii=False, indent=2)}"
    )
    return [
        PromptMessage(role="system", content=system),
        PromptMessage(role="user", content=user),
    ]


def build_fallback_payload(shot: RecapShot) -> dict[str, str]:
    primary_action = derive_primary_action(shot)
    secondary_motion = derive_secondary_motion(shot)
    environment_motion = derive_environment_motion(shot)
    camera_motion = normalize_camera_motion(shot.camera_motion)
    emotion = visible_emotion(shot)
    duration_hint = infer_duration_hint(shot.pace_weight)
    prompt_parts = [primary_action]
    for fragment in (secondary_motion, environment_motion, camera_motion):
        fragment = clean_fragment(fragment)
        if fragment:
            prompt_parts.append(fragment)
    final_prompt = "，".join(prompt_parts).strip("， ") + "。"
    return {
        "episode_id": shot.episode_id,
        "shot_id": shot.shot_id,
        "shot_type": normalize_shot_type(shot.shot_type),
        "primary_action": primary_action,
        "secondary_motion": secondary_motion,
        "environment_motion": environment_motion,
        "camera_motion": camera_motion,
        "emotion": emotion,
        "duration_hint": duration_hint,
        "final_prompt": final_prompt,
    }


def derive_primary_action(shot: RecapShot) -> str:
    text = cleanup_source_text(shot.summary)
    if not text:
        text = cleanup_source_text(shot.anchor_text)
    if not text:
        text = cleanup_source_text(shot.visual_prompt)
    text = re.sub(r"^画面(?:中|里)?", "", text).strip("，,。 ")
    return trim_clause(text, limit=72) or f"{shot.shot_id}中的主体动作继续推进"


def derive_secondary_motion(shot: RecapShot) -> str:
    visual = cleanup_source_text(shot.visual_prompt)
    if any(token in visual for token in ("甩起", "打滑", "流下", "抬起", "摘下", "逼近", "冲到", "支住", "指向", "整队经过")):
        return trim_clause(visual, limit=64)
    return ""


def derive_environment_motion(shot: RecapShot) -> str:
    text = cleanup_source_text(shot.visual_prompt)
    for token, phrase in (
        ("暴雨", "暴雨持续砸下，路面积水和泥浆不断被带起"),
        ("雨幕", "雨幕持续压低视线"),
        ("火花", "焊接火花不断跳动并照亮周围"),
        ("尘土", "尘土或沙粒被动作带起并向后拖开"),
        ("风", "风把衣物或尘沙持续吹动"),
        ("烟雾", "烟雾和热浪轻微扭动周围空气"),
        ("人群", "周围人流继续穿过画面"),
    ):
        if token in text:
            return phrase
    return ""


def visible_emotion(shot: RecapShot) -> str:
    mood = cleanup_source_text(shot.mood)
    if not mood:
        return ""
    return trim_clause(mood.replace(",", "，"), limit=36)


def normalize_shot_type(value: str) -> str:
    lowered = str(value or "").strip().casefold()
    return SHOT_TYPE_MAP.get(lowered, lowered or "shot")


def normalize_camera_motion(value: str) -> str:
    lowered = str(value or "").strip().casefold()
    if not lowered:
        return ""
    return CAMERA_MOTION_MAP.get(lowered, lowered)


def infer_duration_hint(value: str) -> str:
    lowered = str(value or "").strip().casefold()
    return DURATION_HINT_MAP.get(lowered, "3-5s")


def compact_text(value: str, *, limit: int) -> str:
    text = cleanup_source_text(value)
    if len(text) <= limit:
        return text
    return text[:limit].rstrip("，,；;。 ")


def cleanup_source_text(value: str) -> str:
    text = str(value or "").replace("\r\n", " ").replace("\n", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text.strip("，,；;。 ")


def trim_clause(value: str, *, limit: int) -> str:
    text = cleanup_source_text(value)
    if len(text) <= limit:
        return text
    return text[:limit].rstrip("，,；;。 ")


def clean_fragment(value: str) -> str:
    return cleanup_source_text(value)
