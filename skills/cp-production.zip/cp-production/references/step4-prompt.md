# 步骤四：输出关键帧提示词

## 执行目标

- 基于视觉节拍表和资产注册表，为 FLUX.2 klein 生成关键帧/锚帧提示词。
- 这些提示词必须服务于 still-image generation，而不是视频运动生成。
- 每条提示词应对应一个可控、清晰、单帧成立的画面方案。

## 核心原则

### 1. 关键帧提示词是静帧构图，不是 prose 改写

- 不要直接复制小说 prose 或旁白句子。
- 不要写成 recap 式描述。
- 不要写成多阶段动作过程。
- 一条关键帧提示词只描述一个稳定画面。

### 2. 关键帧提示词必须强调可见构图

每条记录至少要明确：
- `shot_size`
- `subject`
- `environment`
- `main_object`
- `composition`
- `lighting`
- `visible_state`
- `style`
- `anchor_image_prompt`

### 3. prompt 风格要求

- 更 literal
- 更 composition-oriented
- 更适合 still-image controllability
- 少情绪解释，多可见信息

避免：
- 象征隐喻
- 主题评论
- 长段心理分析
- 对白文字
- 把动作前后过程塞进同一帧
- 视频镜头语言主导整条提示词

### 4. 不是所有 beat 都必须生成关键帧

- 优先覆盖 `clip_worthy = yes` 的 beat。
- 对视觉上具有定义作用的 `maybe` beat 也可生成关键帧。
- 如果某个 beat 只适合做旁白过渡且无明确静帧价值，可以跳过。

## 输出结构要求

你必须输出一个完整可读文本，并在文末且只在文末提供 **一个** fenced `json` 代码块。

### 可读文本部分建议结构

```text
# 关键帧提示词

## beat_001
- Linked Assets: …
- Shot Size: …
- Subject: …
- Environment: …
- Main Object: …
- Composition: …
- Lighting: …
- Visible State: …
- Style: …
- Anchor Image Prompt: …
```

### JSON 代码块要求

- 文末必须包含一个合法 JSON 代码块。
- 顶层结构必须至少包含：

```json
{
  "project_title": "项目名",
  "anchor_prompts": []
}
```

- `anchor_prompts` 中每个对象必须至少包含：
  - `prompt_id`
  - `beat_id`
  - `linked_assets`
  - `shot_size`
  - `subject`
  - `environment`
  - `main_object`
  - `composition`
  - `lighting`
  - `visible_state`
  - `style`
  - `anchor_image_prompt`

## 质量要求

- 关键帧提示词必须明显区别于视频提示词。
- 重点是“这一帧看起来是什么”，不是“接下来发生什么”。
- 输出必须适合作为后续视频步骤的 anchor reference，而不是替代视频提示词本身。
