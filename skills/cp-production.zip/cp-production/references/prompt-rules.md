# Prompt Rules

## Core Principle

Narration explains the story. Prompts instruct models. They are not interchangeable.

The skill exists to prevent this failure mode:
- raw prose becomes recap text
- recap text gets reused as both image prompt and video prompt
- both models receive bloated, mixed-purpose instructions

Instead, convert story prose into:
- narration script
- beats
- assets
- anchor prompts
- video prompts

## Why Narration Script Is Not a Prompt

- Narration needs spoken clarity, pacing, and emotional readability.
- Prompts need concrete, controllable visual or motion instructions.
- Narration can mention causality, context, and backstory.
- Prompts should mostly describe what is visible and actionable for the model.

## Anchor Prompts for FLUX.2 klein

Anchor prompts are still-image instructions.

Prioritize:
- visible subject
- environment
- main object
- shot size
- composition
- lighting
- visible state
- stable style

Anchor prompt style:
- literal
- composition-oriented
- single-frame
- controllable

Avoid:
- symbolic prose
- theme statements
- long emotional explanation
- dialogue unless visually necessary
- montage language
- multi-stage action in one still
- poetic wording that weakens control

Short rule:
- anchor prompts = visible composition

## Video Prompts for LTX-2

Video prompts assume the anchor frame already covers:
- subject
- scene
- style

So the LTX-2 prompt should emphasize:
- visible motion
- environmental motion
- character action
- camera movement
- pacing or intensity when useful

Video prompt style:
- shorter than the anchor prompt
- motion-first
- clear about the next action
- camera-aware

Avoid:
- re-describing the whole frame
- recap-style summary language
- abstract emotional interpretation without visible cues
- overloaded multi-event action that should have been split into multiple beats

Short rule:
- video prompts = motion + camera

## Simplifying Literary Prose

When the source is literary or poetic:

1. Extract what is actually visible.
2. Separate mood from visible acting or atmosphere.
3. Convert abstract emotion into observable state.
4. Decide whether the moment is better as narration support, anchor image, or motion clip.

Examples:
- `She felt the weight of her past closing in.`
  Better production language:
  `She pauses at the doorway, lowers her eyes, and tightens her grip on the helmet.`

- `The garage looked like a graveyard of broken ambition.`
  Better production language:
  `A dim garage packed with stripped frames, oil stains, hanging tools, and half-covered bikes.`

## Beat-to-Prompt Rules

- One beat may need both an anchor prompt and a video prompt.
- Some beats only need an anchor prompt.
- Some beats only need narration support.
- Not all beats deserve a full clip.
- If a beat contains multiple major actions, split the beat before prompt writing.
