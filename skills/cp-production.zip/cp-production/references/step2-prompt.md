# 步骤二：输出视觉节拍表

## 执行目标

- 将旁白脚本转换为稳定、可执行、可复用的生产节拍表。
- 让 beat 成为后续资产提炼、关键帧提示词和视频提示词的共享规划单元。
- 明确区分完整 clip 候选 beat、插入类 beat、过渡类 beat 和仅适合作为 narration support 的 beat。

## 核心原则

### 1. 按生产节拍拆分，不按句子机械切分

- 一章/一节通常会拆成多个 beat。
- 一个 beat 只承载一个主要动作、一个主要认知变化、一个主要关系变化，或一个主要视觉信息点。
- 不要把多个重大事件塞进一个 beat。
- 也不要把一句话拆成一个 beat，导致过碎。

### 2. beat 是生产单元，不是 recap prose

- `summary` 必须简洁、清晰、可供后续生产理解。
- 不要写成文学性长句。
- 不要写成主题分析、角色解读、象征意义说明。

### 3. 必须做价值判断

- `story_function` 仅允许：
  - `hook`
  - `development`
  - `turn`
  - `payoff`
  - `cliffhanger`
  - `insert`
- `priority` 仅允许：
  - `high`
  - `medium`
  - `low`
- `clip_worthy` 仅允许：
  - `yes`
  - `no`
  - `maybe`
- `duration_class` 仅允许：
  - `short`
  - `medium`
  - `long`

### 4. 每个 beat 至少包含这些字段

- `beat_id`
- `chapter_id`
- `beat_title`
- `summary`
- `story_function`
- `priority`
- `clip_worthy`
- `duration_class`
- `shot_type_suggestion`
- `camera_movement_suggestion`
- `mood`
- `subject_focus`
- `scene_focus`
- `prop_focus`
- `narration_anchor_line`

## 输出结构要求

你必须输出一个完整 Markdown 文档，并在文末且只在文末提供 **一个** fenced `json` 代码块。

### Markdown 部分必须包含

1. 标题
2. 节拍规划总览
3. 按章节或序列分组的 beat 明细

### Markdown 推荐样式

```text
# 视觉节拍表

## ch01

### beat_001
- Beat Title: …
- Summary: …
- Story Function: …
- Priority: …
- Clip Worthy: …
- Duration Class: …
- Shot Type Suggestion: …
- Camera Movement Suggestion: …
- Mood: …
- Subject Focus: …
- Scene Focus: …
- Prop Focus: …
- Narration Anchor Line: …
```

## JSON 代码块要求

- 文末必须包含一个合法 JSON 代码块。
- 代码块外不要再追加解释文字。
- 顶层结构必须至少包含：

```json
{
  "project_title": "项目名",
  "source_file": "novel.txt",
  "beats": []
}
```

- `beats` 内每个对象必须包含本步骤要求的全部字段。
- `beat_id` 应稳定、可读、可排序，例如 `b001`、`b002` 或 `ch01_b01`。
- `chapter_id` 应反映原文章节或你推断出的序列编号。

## 质量要求

- 保持故事顺序。
- 明确 hook、turn、payoff、cliffhanger 的叙事作用。
- 不是每个 beat 都必须值得做完整视频 clip。
- 要为步骤三到步骤五提供足够稳定的信息，但不要提前把它写成提示词。
