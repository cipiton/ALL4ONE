# 步骤五：输出视频提示词

## 执行目标

- 基于视觉节拍表、资产注册表和关键帧提示词，为 LTX-2 生成 motion-first 视频提示词。
- 默认关键帧已经建立主体、场景与风格，因此视频提示词应重点描述“接下来发生什么”。
- 输出必须比关键帧提示词更短、更明确、更偏运动和镜头控制。

## 核心原则

### 1. 不要重写整张静帧

- 不要重新把 subject、environment、style 全部从头讲一遍。
- 只在理解动作所必需时补充静态信息。
- 重点是动作、环境变化、反应和镜头行为。

### 2. prompt 必须 motion-first

每条记录至少要明确：
- `motion_focus`
- `environment_motion`
- `character_action`
- `camera_movement`
- `pacing`
- `video_prompt`

### 3. camera-aware，但不要滥写镜头花活

- 镜头运动必须服务于动作和信息呈现。
- 优先使用清晰可执行的镜头语言，例如：
  - `slow push in`
  - `static frame`
  - `pan right revealing`
  - `handheld follow`
  - `slow tilt up`
- 不要堆砌复杂镜头术语。

### 4. 不是每个 beat 都要生成视频提示词

- 优先覆盖 `clip_worthy = yes` 的 beat。
- 对 `clip_worthy = maybe` 的 beat，只有当其具有明确运动价值时才生成。
- 对 `clip_worthy = no` 或明显只适合静帧/旁白支撑的 beat，可以不生成。

## 输出结构要求

你必须输出一个完整可读文本，并在文末且只在文末提供 **一个** fenced `json` 代码块。

### 可读文本部分建议结构

```text
# 视频提示词

## beat_001
- Linked Anchor Prompt: …
- Linked Assets: …
- Motion Focus: …
- Environment Motion: …
- Character Action: …
- Camera Movement: …
- Pacing: …
- Video Prompt: …
```

### JSON 代码块要求

- 文末必须包含一个合法 JSON 代码块。
- 顶层结构必须至少包含：

```json
{
  "project_title": "项目名",
  "video_prompts": []
}
```

- `video_prompts` 中每个对象必须至少包含：
  - `prompt_id`
  - `beat_id`
  - `linked_anchor_prompt_id`
  - `linked_assets`
  - `motion_focus`
  - `environment_motion`
  - `character_action`
  - `camera_movement`
  - `pacing`
  - `video_prompt`

## 质量要求

- 视频提示词必须与关键帧提示词区分清楚。
- 关键帧提示词回答“这一帧是什么”；视频提示词回答“这一帧之后怎么动、镜头怎么跟”。
- 不要输出 recap 风格 prose。
- 不要输出只有情绪没有动作的空泛描述。
- 输出必须适合后续 LTX-2 使用。
