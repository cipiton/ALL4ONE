---
name: novel_adaptation_plan
display_name: Novel Adaptation Plan
description: Multi-step novel adaptation planning workflow for normalizing long-form source material, extracting commercial set pieces, planning pacing phases, and delivering a substantive short-drama adaptation package.
supports_resume: true
input_extensions:
  - .txt
folder_mode: non_recursive
metadata:
  aliases:
    - short_drama_adaption
    - short-drama-adaption
  startup:
    mode: explicit_step_selection
    default_step: 1
    allow_resume: true
    allow_auto_route: false
  execution:
    mode: sequential_with_review
    continue_until_end: true
    preview_before_save: true
    save_only_on_accept: true
  model_routing:
    step_execution_model: fast
    final_deliverable_model: strong
    project_master_outline_model: strong
system_instructions: |
  If source_mode=project_ingested or source_type=synthesized_master_outline, treat the provided dossier as sufficient working source material.
  In that case, operate in best-effort production mode:
  - do not ask the user to confirm missing inputs
  - do not output a questionnaire, checklist, or requirements request
  - make conservative assumptions where details are missing
  - produce a substantive adaptation plan directly
  Default to a 60-episode vertical short-drama structure when no explicit episode count is provided.
  The final output must include: adaptation positioning, compression/omission strategy, principal characters and functions, major arcs, stage/episode structure, key set pieces/reversals, tone/style notes, and production-facing planning notes.
  Only mention blockers briefly at the end if generation is truly impossible; blockers must never replace the deliverable.

steps:
  - number: 1
    id: adaptation_source_normalization
    title: 读取并规范原稿
    description: Normalize the source novel or synthesized master outline into adaptation-ready material with explicit assumptions and continuity anchors.
    prompt_reference: step1_prompt
    write_to: adaptation_source
    output_filename: 01_adaptation_source.txt
    model_role: step_execution
    default: true
    input_blocks:
      - label: 【原始小说/母本档案】
        from: user_brief
  - number: 2
    id: set_piece_extraction
    title: 提炼名场面与核心卖点
    description: Extract set pieces, hooks, reversals, emotional peaks, and the commercial adaptation selling points.
    prompt_reference: step2_prompt
    write_to: commercial_hooks
    output_filename: 02_commercial_hooks.txt
    model_role: step_execution
    input_blocks:
      - label: 【改编底稿】
        from: adaptation_source
  - number: 3
    id: pacing_structure_planning
    title: 规划阶段节奏与分集结构
    description: Build the phase pacing, episode structure, and hook distribution for the adaptation.
    prompt_reference: step3_prompt
    write_to: pacing_structure
    output_filename: 03_pacing_structure.txt
    model_role: step_execution
    input_blocks:
      - label: 【改编底稿】
        from: adaptation_source
      - label: 【名场面与卖点】
        from: commercial_hooks
  - number: 4
    id: final_adaptation_plan
    title: 输出最终改编方案
    description: Deliver the final substantive adaptation plan package for writers and production stakeholders.
    prompt_reference: step4_prompt
    write_to: final_adaptation_plan
    output_filename: 04_final_adaptation_plan.txt
    model_role: final_deliverable
    input_blocks:
      - label: 【改编底稿】
        from: adaptation_source
      - label: 【名场面与卖点】
        from: commercial_hooks
      - label: 【阶段节奏与分集结构】
        from: pacing_structure

references:
  - id: step1_prompt
    path: references/step1-prompt.md
    kind: prompt
    step_numbers:
      - 1
  - id: step2_prompt
    path: references/step2-prompt.md
    kind: prompt
    step_numbers:
      - 2
  - id: step3_prompt
    path: references/step3-prompt.md
    kind: prompt
    step_numbers:
      - 3
  - id: step4_prompt
    path: references/step4-prompt.md
    kind: prompt
    step_numbers:
      - 4

execution:
  strategy: step_prompt

output:
  mode: text
  filename_template: "step_{step_number}_output.txt"
  include_prompt_dump: true
---

# Novel Adaptation Plan

Use this skill to turn long-form source material or a synthesized master outline into a commercially usable short-drama adaptation plan.

## Shared Runtime Behavior

- The shared runtime starts from the selected step.
- Each step generates a draft, previews it, and waits for `Accept`, `Improve`, `Restart`, `View full`, or `Cancel`.
- Only accepted outputs are saved.
- After acceptance, the shared runtime automatically continues to the next step until the workflow ends or the user cancels.
- Resume is supported from the latest accepted step output.

## Project-Ingested Mode

- When the input carries `source_mode: project_ingested` / `source_type: synthesized_master_outline`, treat the consolidated dossier as the authoritative working source.
- In that mode, produce best-effort deliverables directly instead of reverting to a confirmation sheet or request-for-more-materials response.
- If the source does not specify an episode count, default to a `60集` vertical short-drama plan and note that assumption inside the output naturally.

## Workflow

### Step 1: 读取并规范原稿

- Read the source text or master outline.
- Normalize the adaptation scope, world rules, major characters, timeline anchors, and continuity constraints.
- Produce one adaptation-ready source package that later steps can trust.

### Step 2: 提炼名场面与核心卖点

- Extract the strongest conflicts, reversals, emotional peaks, identity reveals, and commercial hooks.
- Group them into adaptation selling points and set-piece assets.
- Keep the result specific enough to guide later episode planning.

### Step 3: 规划阶段节奏与分集结构

- Turn the normalized source and set-piece package into stage pacing and episode structure.
- Allocate hooks, reversals, and emotional peaks across the adaptation.
- Keep the structure suitable for vertical short-drama retention and payment beats.

### Step 4: 输出最终改编方案

- Deliver the final substantive adaptation plan.
- The result must be useful for writing, development, and production planning.
- Do not output questionnaires, blockers-only notes, or meta commentary in the final step.

## Final Deliverable Expectations

- Project premise / adaptation positioning
- Compression / omission strategy
- Principal characters and dramatic functions
- Major arcs and set-piece map
- Stage pacing and episode structure
- Hook and reversal placement
- Tone / style / production notes
- Writer-facing or production-facing implementation guidance
