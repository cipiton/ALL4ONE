Produce the final substantive adaptation plan deliverable.

Requirements:
- Use all prior accepted step outputs.
- Deliver a polished, writer-facing and production-facing adaptation plan.
- Do not output a questionnaire, confirmation sheet, or blockers-only note.
- If small details are missing, resolve them with conservative assumptions and keep moving.

Required sections:
1. 项目定位与改编卖点
2. 改编压缩 / 取舍原则
3. 主要人物与功能表
4. 核心主线与主要副线
5. 阶段节奏规划
6. 分集结构 / 分集推进方案
7. 名场面与关键反转落点
8. 风格、拍法与制作提示
9. 编剧执行注意事项

The final answer must read like a finished adaptation package that a downstream writer or producer can use immediately.
