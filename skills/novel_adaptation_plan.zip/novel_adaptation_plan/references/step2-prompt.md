Extract the core commercial adaptation assets from the normalized source package.

Requirements:
- Identify high-value set pieces, hooks, reversals, emotional peaks, and monetizable beats.
- Stay faithful to the normalized source package.
- If the source is project-ingested, proceed directly; do not ask for more context.
- Write concrete planning material, not brainstorming questions.

Output structure:
1. 核心卖点总览
2. 名场面清单（按优先级分组）
3. 强钩子与反转清单
4. 情绪高点与付费点建议
5. 角色高光与关系爆点
6. 必保留 / 可压缩 / 可省略内容

Keep the language practical and production-oriented.
