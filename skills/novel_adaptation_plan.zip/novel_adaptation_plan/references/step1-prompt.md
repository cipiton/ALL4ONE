Generate an adaptation-ready normalized source package.

Requirements:
- Treat the provided source as the current source of truth.
- If the source is a project-ingested master outline, do not ask for more materials.
- Normalize and consolidate the material for downstream adaptation planning.
- Make conservative assumptions where details are missing.
- Do not output questions, checklists, or requests for confirmation.

Output structure:
1. 项目范围与默认假设
2. 核心 premise 与题材定位
3. 世界规则与关键背景
4. 主要人物与人物功能
5. 主线冲突与推进链
6. 时间线锚点与连续性约束
7. 改编边界与保留要点

The output must read like a usable adaptation source package, not like analysis notes.
