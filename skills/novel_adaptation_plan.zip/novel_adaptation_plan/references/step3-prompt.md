Build the pacing phases and episode structure for the adaptation.

Requirements:
- Use the normalized source package and the extracted selling points.
- Default to a 60-episode vertical short-drama structure if the source does not provide an explicit episode count.
- Distribute hooks, reversals, and emotional peaks across the structure.
- Do not ask clarifying questions. Make conservative assumptions and continue.

Output structure:
1. 总体阶段规划
2. 各阶段目标与核心节奏
3. 分集结构规划（或分段分集总包）
4. 每阶段名场面绑定策略
5. 每阶段结尾钩子原则
6. 节奏风险与修正建议

The result must be concrete enough to drive final adaptation-plan writing.
